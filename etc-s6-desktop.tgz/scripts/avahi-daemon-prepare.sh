#!/bin/sh
rm -f /run/avahi-daemon/pid
