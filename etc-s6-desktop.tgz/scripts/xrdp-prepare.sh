#!/bin/bash
rm -f /var/run/xrdp/xrdp.pid > /dev/null 2>&1
