#!/bin/bash
RUNDIR=/run/dbus
PIDFILE="$RUNDIR/pid"
if [ ! -d "$RUNDIR" ]; then
   mkdir $RUNDIR
fi
if [ -f "$PIDFILE" ]; then
   rm -f $PIDFILE
fi
