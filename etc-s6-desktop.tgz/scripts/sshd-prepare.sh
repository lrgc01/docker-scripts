#!/bin/bash
RUNDIR=/run/sshd
PIDFILE="$RUNDIR/pid"

if [ ! -d "$RUNDIR" ]; then
   mkdir $RUNDIR
fi
if [ -f "$PIDFILE" ]; then
   rm -f $PIDFILE
fi

SCREENDIR=/run/screen
if [ ! -d "$SCREENDIR" ]; then
   mkdir $SCREENDIR
   chmod 1777 $SCREENDIR
fi
