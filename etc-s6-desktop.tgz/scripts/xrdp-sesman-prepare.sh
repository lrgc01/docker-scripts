#!/bin/bash
rm -f /var/run/xrdp/xrdp-sesman.pid > /dev/null 2>&1
